/** Automatically generated file. DO NOT MODIFY */
package edu.neu.madcourse.binbo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}