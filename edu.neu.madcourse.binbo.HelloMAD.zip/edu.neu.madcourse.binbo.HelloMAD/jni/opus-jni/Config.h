#ifndef CONFIG_H_
#define CONFIG_H_

//#define DEBUG
//#define LOG_TO_FILE

//#ifndef iOS
//#define iOS
//#endif

#ifndef ANDROID
#define ANDROID
#endif

#endif
