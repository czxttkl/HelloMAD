#ifndef SYS_CONSTS_H_
#define SYS_CONSTS_H_

#define TRUE	1
#define FALSE	0

#define S_OK                 0
#define E_FAIL              -1  
#define E_NOIMPL            -2 
#define E_OUTOFMEMORY       -3   
#define E_IO                -4 

#endif
