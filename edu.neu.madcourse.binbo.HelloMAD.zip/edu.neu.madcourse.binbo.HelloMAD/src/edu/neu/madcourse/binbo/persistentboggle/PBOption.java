package edu.neu.madcourse.binbo.persistentboggle;

import android.app.Activity;

public class PBOption extends Activity {

}
