package edu.neu.madcourse.binbo.persistentboggle;

import android.app.Activity;

public class PBAcknowledge extends Activity {

}
