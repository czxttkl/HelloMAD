package edu.neu.madcourse.binbo.persistentboggle;

import edu.neu.madcourse.binbo.R;
import edu.neu.madcourse.binbo.R.layout;
import android.app.Activity;
import android.os.Bundle;

public class PBAbout extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pb_about);
	}
}
