package edu.neu.madcourse.binbo.boggle;

import edu.neu.madcourse.binbo.R;
import edu.neu.madcourse.binbo.R.layout;
import android.app.Activity;
import android.os.Bundle;

public class BoggleAbout extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.boggle_about);
	}
}
