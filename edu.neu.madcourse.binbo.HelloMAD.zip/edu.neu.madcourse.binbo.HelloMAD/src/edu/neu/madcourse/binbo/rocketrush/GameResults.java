package edu.neu.madcourse.binbo.rocketrush;

import java.io.Serializable;
import java.util.ArrayList;

public class GameResults extends ArrayList<GameResult> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5974742058904024603L;

}
